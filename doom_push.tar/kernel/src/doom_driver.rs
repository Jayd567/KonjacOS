//! Rust-side glue for `csrc/doom/doomgeneric_konjac.c`, the platform
//! driver implementing doomgeneric's six-function porting API
//! (`DG_Init`/`DG_DrawFrame`/`DG_SleepMs`/`DG_GetTicksMs`/`DG_GetKey`/
//! `DG_SetWindowTitle`). Kept in its own module (rather than folded into
//! `keyboard.rs`/`timer.rs`/`framebuffer.rs` directly) since none of this
//! is anything those modules would otherwise have a reason to expose --
//! it's DOOM-specific plumbing on top of general-purpose facilities they
//! already provide.

use crate::console;
use crate::keyboard;
use crate::task;
use crate::timer;

/// Blits doomgeneric's 640x400 XRGB8888 screen buffer (`DG_ScreenBuffer`,
/// always this fixed size regardless of the actual `SCREENWIDTH`/
/// `SCREENHEIGHT` DOOM renders at -- see `i_video.c`'s `cmap_to_fb`/
/// `fb_scaling` dance, which upscales into it) onto the kernel's real
/// framebuffer, centered if the screen is larger. Whatever's simplest
/// correct thing to do -- if this ever needs to be fast, the obvious next
/// step is precomputing a look-up-table-free tight inner loop instead of
/// calling `put_pixel` (which repacks the channel layout) once per pixel,
/// but 640x400 at a few frames per second is more than enough to prove
/// the whole pipeline actually works.
///
/// # Safety
/// `buf` must point at `width * height` valid `u32` pixels in `0x00RRGGBB`
/// order (doomgeneric's own convention for a 32bpp `pixel_t`, confirmed by
/// reading `i_video.c`'s `cmap_to_fb`).
#[unsafe(no_mangle)]
pub unsafe extern "C" fn konjac_doom_blit(buf: *const u32, width: u32, height: u32) {
    let mut console = console::CONSOLE.lock();
    let Some(canvas) = console.canvas_mut() else { return };

    let (cw, ch) = (canvas.width(), canvas.height());
    let (w, h) = (width as u64, height as u64);
    let x_off = if cw > w { (cw - w) / 2 } else { 0 };
    let y_off = if ch > h { (ch - h) / 2 } else { 0 };
    let draw_w = w.min(cw);
    let draw_h = h.min(ch);

    for y in 0..draw_h {
        for x in 0..draw_w {
            // Safety: `x < width` and `y < height` (both bounded by
            // draw_w/draw_h above), so this stays within the `width *
            // height` pixels the caller promised are valid.
            let pixel = unsafe { *buf.add((y * w as u64 + x) as usize) };
            let r = ((pixel >> 16) & 0xff) as u8;
            let g = ((pixel >> 8) & 0xff) as u8;
            let b = (pixel & 0xff) as u8;
            canvas.put_pixel(x_off + x, y_off + y, r, g, b);
        }
    }
}

/// Milliseconds since `timer::init()`, derived from the PIT's 100 Hz tick
/// counter (10ms resolution -- plenty for DOOM's own ~35 Hz internal
/// tic rate).
#[unsafe(no_mangle)]
pub extern "C" fn konjac_doom_ticks_ms() -> u32 {
    (timer::ticks() * 1000 / timer::HZ as u64) as u32
}

/// Busy-waits (yielding to the scheduler each spin, so other tasks --
/// notably the shell -- keep running) until at least `ms` milliseconds
/// have passed. There's no real sleep/timer-queue primitive in `task.rs`
/// yet, and DOOM only ever sleeps for single-digit-to-low-double-digit
/// millisecond spans (frame pacing), so this is adequate without needing
/// one.
#[unsafe(no_mangle)]
pub extern "C" fn konjac_doom_sleep_ms(ms: u32) {
    let start = konjac_doom_ticks_ms();
    while konjac_doom_ticks_ms().wrapping_sub(start) < ms {
        task::yield_now();
    }
}

/// # Safety
/// `pressed`/`key` must be valid, non-null, writable pointers.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn konjac_doom_get_key(pressed: *mut i32, key: *mut u8) -> i32 {
    match keyboard::read_doom_event() {
        Some((was_pressed, doomkey)) => {
            unsafe {
                *pressed = was_pressed as i32;
                *key = doomkey;
            }
            1
        }
        None => 0,
    }
}
