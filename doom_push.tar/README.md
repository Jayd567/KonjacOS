# KonjacOS

A from-scratch x86_64 operating system kernel, written in Rust, booted via
[Limine](https://limine-bootloader.org/). It's a genuine bare-metal kernel --
no Linux underneath it anywhere, despite the Rust *compiler target* name
having "linux" in it (see [Toolchain notes](#toolchain-notes) for why).

Confirmed working, boot-tested in QEMU after every milestone below (not just
"it compiles"):

* Boots via Limine, brings up serial diagnostics, reads the memory map and
  framebuffer, draws a boot splash.
* A real GDT/TSS and a full IDT: CPU exceptions print a fault message and
  halt instead of triple-faulting the machine.
* The legacy PIC remapped, a PIT timer interrupt at 100Hz, and a PS/2
  keyboard driver (both IRQ-driven, not polled).
* A scrolling framebuffer text console (embedded 8x8 font) with a blinking
  text cursor, and a `sprintln!`-style serial console for boot diagnostics
  that's separate from it.
* A physical frame allocator (bitmap, built on Limine's HHDM), a page-table
  extension layer on top of Limine's existing paging, and a heap with a
  `#[global_allocator]` -- `alloc::vec::Vec`, `String`, etc. all work.
* An ATA PIO disk driver (read *and* write) and a read-only-no-longer FAT16
  filesystem driver: subdirectories, `cd`/`pwd` with a real current
  directory, and file create/overwrite/delete. The disk image is an
  ordinary FAT16 volume built with standard host tools (`mkfs.vfat`/
  `mtools`), so anything FAT-aware can read or write it too.
* An interactive shell dispatched through a command table (not a hardcoded
  match) -- see [Shell commands](#shell-commands) below.

## Quick start

Prerequisites (all already present if you're building in the same
environment this was scaffolded in): `cargo`/`rustc` (stable -- no nightly
needed, see [Toolchain notes](#toolchain-notes)), `xorriso`,
`qemu-system-x86_64`, `mkfs.vfat`/`mcopy` (from `dosfstools`/`mtools`, for
the data disk -- optional, see below), and optionally the `ovmf` package for
UEFI testing.

```sh
make run        # build everything and boot it in QEMU (BIOS)
make run-uefi    # same, but via OVMF/UEFI
```

You should see boot diagnostics scroll by on stdout (the kernel's serial
console), and in the QEMU window: a boot splash, then the `konjac>` shell
prompt with a blinking cursor.

Other targets:

```sh
make kernel             # just build the kernel ELF, no ISO
make iso                # build kernel + image.iso, don't run it
make disk               # build disk.img (FAT16) from disk_root/
make clean              # remove build output (leaves disk.img alone)
make MODE=release run   # optimized build instead of the default dev build
```

`make disk` needs `mkfs.vfat` and `mcopy` (Debian/Ubuntu:
`apt install dosfstools mtools`). If they're missing it's skipped with a
warning -- the OS still boots and the shell still works, just without a
filesystem to `ls`/`cat`/`write` against.

## Shell commands

Type `help` at the `konjac>` prompt for the live list (generated from the
command table, so it can't drift out of sync with reality). As of this
writing:

| Command | Does |
|---|---|
| `help` | list commands |
| `echo <text>` | print text back |
| `clear` | clear the screen |
| `uptime` | timer ticks / elapsed time |
| `meminfo` | physical frame + heap usage, plus a heap self-test |
| `alloc <n>` | heap-allocate a `Vec<u32>` of `n` elements and sum it |
| `about` | what this is |
| `ls` | list the current directory |
| `cd [dir]` | change directory (`..`, `/`, multi-level paths); no args prints cwd |
| `pwd` | print the current directory |
| `cat <file>` | print a file's contents |
| `write <file> <text>` | create/overwrite a file |
| `rm <file>` | delete a file **[apex]** |
| `reboot` | reset the machine (8042 controller reset) **[apex]** |
| `halt` | stop the CPU **[apex]** |
| `apex` | show whether an apex check is currently cached |
| `ps` | list running kernel threads (id, state, timer ticks handed to each) |
| `gui` | open the window manager (drag windows by their title bar; Esc to exit) |
| `cdemo` | run a small compiled-C function (malloc/free) -- DOOM-porting groundwork |
| `cio` | run compiled-C printf + file I/O (fopen/fread/fwrite) -- DOOM-porting groundwork |
| `doom` | launch DOOM (needs `DOOM1.WAD` at the filesystem root; one-way until reboot) |

Commands marked **[apex]** prompt for a password the first time they (or
any other apex command) run -- choosing one, the first time ever -- then
cache success for 5 minutes. The password's SHA-256 hash lives at
`/APEX.PWD` on the disk, not the password itself.

## Project layout

```
kernel/                 The Rust kernel crate (the actual OS code)
  src/
    boot.rs               Real ELF entry point: enables SSE, aligns the
                           stack, jumps into kstart().
    main.rs                kstart(): brings up every subsystem below in
                           order and hands off to the shell.
    limine.rs              Hand-written Limine boot protocol bindings.
    serial.rs              16550 UART driver (COM1) + sprint!/sprintln!.
    gdt.rs                 GDT + TSS, incl. the double-fault IST stack.
    idt.rs                 IDT + exception handlers + hardware-IRQ stubs.
    pic.rs                 Legacy 8259 PIC remap/mask/EOI.
    timer.rs               PIT driver, IRQ0, tick counter.
    keyboard.rs             PS/2 driver, IRQ1, scancode -> ASCII, ring buffer.
    framebuffer.rs          Pixel/rect drawing + glyph blitting on the
                           Limine framebuffer.
    font.rs                 Embedded 8x8 bitmap font.
    console.rs              Scrolling text console + blinking cursor, on
                           top of framebuffer.rs.
    pmm.rs                  Bitmap physical frame allocator (on Limine's HHDM).
    paging.rs               Extends Limine's page tables with new mappings.
    heap.rs                 GlobalAlloc free-list allocator.
    memory.rs               Ties pmm+heap init together; meminfo's backend.
    ata.rs                  ATA PIO disk driver (read + write).
    fat16.rs                Read/write FAT16 driver: dirs, cd/pwd, files.
    commands.rs             The shell's command table + builtin handlers.
    apex.rs                  sudo-style password gate for requires_apex commands.
    sha256.rs                Hand-written SHA-256 (apex's password hashing).
    task.rs                  Preemptive kernel-thread scheduler + context switch.
    syscall.rs                int 0x80 syscall gate (write, exit).
    usermode.rs                Hand-assembled ring-3 demo program + loader;
                               spawns two isolated instances to prove
                               per-task address spaces actually isolate.
    mouse.rs                  PS/2 mouse driver, IRQ12, 3-byte packet decode.
    cursor.rs                  The real cursor-pack asset (extracted from
                               .cur, baked in via include_bytes!).
    wm.rs                      Minimal window manager: snapshot/blit compositor,
                               draggable windows, alpha-blended cursor.
    shell.rs                Line editing + dispatch loop.
    port.rs                 in/out port I/O wrappers (incl. insw/outsw).
    sync.rs                 A minimal spinlock.
    intrinsics.rs           memcpy/memset/memmove/memcmp/strlen -- see
                           toolchain notes.
    libc_shim.rs             malloc/free/calloc/realloc for compiled-in C
                             code (DOOM-porting groundwork), onto heap.rs.
    cfile.rs                 fopen/fclose/fread/fwrite/fseek/... + stdout/
                             stderr for compiled-in C code, onto fat16.rs.
    doom_driver.rs           Rust-side glue for doomgeneric_konjac.c:
                             blits DG_ScreenBuffer onto framebuffer.rs's
                             Canvas, ticks/sleep onto timer.rs, key events
                             onto keyboard.rs's DOOM_RING.
  csrc/                    Freestanding C sources:
                           cdemo.c (malloc/free), printf.c (the printf
                           family), iodemo.c (printf + file I/O together),
                           sscanf.c, doom_math.c (sin/cos/tan/atan/fabs via
                           x87 asm), doom_string.c (the rest of string.h).
                           Compiled by build.rs and linked into the kernel.
    doom/                  doomgeneric's own sources (81 .c + 97 .h,
                           GPL-2.0 -- see LICENSE.doomgeneric in this
                           directory) plus doomgeneric_konjac.c, the
                           KonjacOS platform driver implementing DG_Init/
                           DG_DrawFrame/DG_SleepMs/DG_GetTicksMs/
                           DG_GetKey/DG_SetWindowTitle.
    doom_include/           Freestanding libc header shims doomgeneric's
                           sources #include (stdint.h, string.h, stdio.h,
                           math.h, ...) -- compiled with -nostdinc so
                           these are the only headers ever seen.
  assets/                 Binary assets baked into the kernel via
                           include_bytes! (currently cursor_arrow.rgba).
  build.rs                Compiles csrc/ with clang/cc/gcc, links the
                           result into the kernel binary.
  linker.ld               Higher-half link layout Limine expects.
  .cargo/config.toml      Target + linker flags (see toolchain notes).
boot/limine.conf          Limine's own boot menu config.
limine/                   Prebuilt Limine binaries + limine.h (source of
                           truth for the protocol structs in limine.rs).
disk_root/                Source files for the FAT16 data disk (`make disk`
                           copies this onto disk.img, subdirectories
                           included), including DOOM1.WAD (id Software's
                           freely-redistributable 1995 shareware release).
Makefile                  Build orchestration (kernel -> ISO + disk -> QEMU).
```

## Toolchain notes

This kernel is built with **stable Rust**, no `rustup target add`, no
nightly, no `-Z build-std`. That's unusual for OS dev in Rust -- most
tutorials (including the well-known "Writing an OS in Rust" blog) have you
install nightly and a custom `x86_64-unknown-none` target. That path needs
downloading a new target's `core`/`alloc` build from `static.rust-lang.org`,
which isn't always available (it wasn't in the sandbox this was built in).

The trick used instead: compile for the *host* target
(`x86_64-unknown-linux-gnu`, which `rustup` already has `core`/`alloc` for)
as `#![no_std]`, and hand the linker a completely different, freestanding
memory layout via `linker.ld`. The generated machine code is identical
either way -- only the Rust-level `target_os` cfg differs, and this kernel
never reads it. This is *not* "running on Linux" in any sense -- there's no
libc, no syscalls, no Linux code anywhere in the binary; it's a Limine-only
naming coincidence. See the comments in `kernel/Cargo.toml` and
`kernel/.cargo/config.toml` for the full flag-by-flag rationale.

Consequences of this choice, and where they show up:

* **No libc, so no `memcpy`/`memset`/`memmove`/`memcmp`.** The
  `compiler_builtins` crate assumes libc provides these on a "linux-gnu"
  target. `intrinsics.rs` provides simple byte-at-a-time versions instead.
* **`x86_64-unknown-linux-gnu`'s prebuilt `core` assumes SSE2 is available**
  (that's the default baseline for the target) and uses it for plain bulk
  data copies, not just float math. Limine does *not* guarantee SSE is
  enabled on kernel entry -- this was caught by actually booting in QEMU
  (an early `movups` faulted with #GP because `CR4.OSFXSR` was 0).
  `boot.rs`'s `_entry` stub enables it before anything else runs.
* Relatedly, **the stack must be 16-byte aligned before calling into Rust**
  (the SysV ABI requires it, and the compiler relies on it for aligned SSE
  stores). Limine's initial stack alignment shouldn't be trusted, so
  `_entry` does `and rsp, -16` defensively.
* **No `limine` crate dependency.** The current version on crates.io needs
  a nightly-only feature (`ptr_metadata`). `limine.rs` hand-translates the
  handful of protocol structs this kernel needs, straight from
  `limine/limine.h`. This also means: if you add a new Limine feature
  request later (modules, SMP, RSDP, ...), you'll want to translate its
  struct from `limine.h` the same way, or switch to the crate once you're
  on nightly.
* **The red zone used to not be disabled** (unlike a real bare-metal
  target, which sets `disable-redzone=true` by default) -- with interrupts
  firing continuously (the 100Hz timer), a leaf function using it could in
  principle have it clobbered by an interrupt arriving mid-leaf. Closed as
  part of the DOOM-porting groundwork (see the roadmap below): `.cargo/
  config.toml` now passes `-C no-redzone` explicitly, and every C
  compilation (`build.rs`) passes the matching `-mno-red-zone`.
* **Avoid `alloc::format!`.** It links fine syntactically but fails at link
  time with `undefined symbol: _Unwind_Resume` -- the prebuilt `alloc.rlib`
  in the stable sysroot was itself compiled assuming `panic = "unwind"`,
  and `format!`'s internals pull in an unwinding path from it that has
  nothing to resolve against under this kernel's `panic = "abort"`. Plain
  `write!`/`print!`/`println!` (going through `core::fmt::Write`, as
  `console.rs`'s macros already do) don't hit this, so they're the way to
  build formatted output here; found while wiring up `apex.rs`'s prompts.
  **`alloc::string::String::from_utf8_lossy` hits the exact same
  `_Unwind_Resume` wall** -- found again while wiring up `cfile.rs`'s C
  string handling. `cfile.rs` has its own small hand-rolled, ASCII-only
  lossy-bytes-to-`String` helper instead; good enough for C strings that
  are ASCII in every case that actually reaches this kernel.
* **The heap's minimum alignment is 16, not 8**, specifically because
  `task.rs` allocates each kernel thread's `fxsave`/`fxrstor` scratch area
  on the heap, and both instructions fault on anything less than 16-byte
  aligned. `heap.rs`'s allocator rejects any request for *more* alignment
  than its `MIN_ALIGN` constant, so this had to be raised rather than
  worked around per-allocation -- worth remembering if a future allocation
  ever needs stricter alignment still (SIMD types wider than SSE, say).
* **`mov reg, symbol` is ambiguous in GNU as's Intel-syntax mode** when
  `symbol` is a `.set`/`=` absolute constant (as opposed to a real label):
  it assembles as a *memory load from that address*, not "load this
  constant value" -- caught by `usermode.rs`'s demo program page-faulting
  on boot at the exact address its own message length happened to equal.
  Fixed by loading from an explicit `[rip + label]` quadword instead of a
  bare symbol; worth remembering for any future hand-written `global_asm!`
  that wants to load a compile-time constant rather than dereference one.

If you later install a nightly toolchain plus the `rust-src` component and
want the more common `x86_64-unknown-none` + `build-std` setup instead, the
change is small: point `.cargo/config.toml`'s `target` at
`x86_64-unknown-none`, add a `[unstable] build-std = ["core", "alloc"]`
section, and you can likely delete `intrinsics.rs` and switch to the real
`limine` crate (this also fixes the red-zone gap above for free, since that
target disables it by default). Everything else (the linker script,
`boot.rs`'s SSE-enable dance, the protocol bindings) still applies -- those
aren't consequences of the stable-toolchain trick, they're just true of
Limine kernels in general.

## Where to go next

Roughly the order being worked through, each building on what's before it:

1. ~~GDT~~, ~~IDT + exception handlers~~, ~~PIC + IRQs~~ -- done.
2. ~~Physical frame allocator~~, ~~paging abstraction~~, ~~heap +
   `#[global_allocator]`~~ -- done.
3. ~~Keyboard driver + text console~~, ~~PIT timer + blinking cursor~~ --
   done.
4. ~~Disk driver (ATA PIO) + filesystem (FAT16, incl. subdirectories and
   writing)~~ -- done.
5. ~~Command-table shell refactor~~ (extensible dispatch instead of a
   hardcoded match) -- done.
6. ~~**apex**~~ -- a `sudo`-style privilege gate: `apex.rs` hashes
   (SHA-256, hand-written -- see toolchain notes) and persists a password
   to `/APEX.PWD` on first use, then prompts for it (masked input, 3
   attempts, a 5-minute success cache) before any command flagged
   `requires_apex` runs -- currently `reboot`, `halt`, and `rm`. Run
   `apex` with no arguments to check whether a check is currently cached.
   Done.
7. ~~**Multitasking**~~ -- `task.rs`: a fixed-size table of kernel threads,
   a hand-written `switch_to` (assembly, saves/restores just the System V
   callee-saved registers + RSP), and a round-robin scheduler that
   `timer.rs`'s IRQ0 handler drives every tick, so it's genuinely
   preemptive, not cooperative -- a tight `loop {}` in one task can't starve
   the others. Every task is still ring 0, sharing the one address space
   (kernel threads, not full processes with their own memory). The tricky
   part was giving every task its own `fxsave`/`fxrstor` scratch buffer
   instead of the single shared one the pre-multitasking timer ISR used --
   a fixed buffer would let one task's interrupt clobber another's not-yet-
   restored FPU state before it resumed. Two demo threads (`counter-a`/`-b`)
   spin in the background from boot; `ps` shows every task's id/state/ticks
   -- watch it climb in lockstep across all three (them plus the shell) as
   proof the round-robin is real. Done.
8. ~~**User mode + syscalls**~~ -- ring 3 execution and an `int 0x80`
   syscall gate. `gdt.rs` grew a DPL=3 code/data selector pair and a
   `set_kernel_stack` (TSS RSP0) that `task.rs`'s scheduler now updates on
   every switch, so a syscall or fault from ring 3 always lands on a real
   stack; `paging.rs` grew `PAGE_USER`, required at *every* page-table
   level (not just the leaf) for CPL=3 to reach a page at all; `idt.rs`
   grew a DPL=3 gate variant, since a ring-3 `int n` needs the gate itself
   to allow it or the CPU refuses with a #GP before the handler ever runs.
   `syscall.rs` is the actual gate: syscall number in `rax`, up to two
   args in `rdi`/`rsi`, two syscalls so far (`write`, `exit`) named after
   their Linux counterparts for familiarity though nothing else about the
   ABI matches. `usermode.rs` hand-assembles a tiny demo program (there's
   no ELF loader yet), copies it to a freshly `PAGE_USER`-mapped page
   (deliberately *not* run in place from the kernel's own `.text`, which
   has no `PAGE_USER` bit anywhere), and runs it as a real task -- it
   prints a message via `write` and exits via `exit`, both confirmed
   working in QEMU (message appears on screen before the shell banner;
   `ps` shows it afterward as `terminated`, having run for exactly one
   scheduler tick). Process isolation came later, as its own step -- see
   item 9.5 below; `write`'s pointer argument is still trusted, not
   validated, within a task's own address space, which is a separate gap.
   Done.
9. ~~**GUI groundwork**~~ -- a PS/2 mouse driver (`mouse.rs`: 8042 aux-device
   enable sequence, IRQ12, the classic 3-byte relative-movement packet
   format, Y-axis inverted since PS/2 reports "up" as positive) and a
   minimal compositor (`wm.rs`). No damage tracking: `gui` freezes the
   whole framebuffer once as a background (`framebuffer.rs`'s
   `snapshot`/`blit`, which needed the heap bumped from 1 MiB to 16 MiB --
   a single 1280x800x32bpp snapshot alone is ~4 MiB), then redraws
   everything -- two demo windows plus a real mouse cursor -- from that
   frozen snapshot every frame something changes. Windows are draggable
   by their title bar (hit-test + remove/push-to-front for z-order), `Esc`
   restores the background and returns to the shell. Still not a real
   desktop: windows are decoration, not separate running programs -- that
   needs an actual GUI task-hosting model built on top of item 9.5's
   isolation, not just the isolation itself.

   The cursor itself is the real thing, not a placeholder: `cursor.rs`
   embeds `arrow.cur` from the "Minimalistic Modern Cursor Set" pack found
   earlier (32x32, genuinely alpha-channeled, not just a 1-bit AND mask),
   extracted offline with a small Python script into a flat RGBA byte blob
   (`kernel/assets/cursor_arrow.rgba`) and pulled into the kernel binary
   with `include_bytes!` rather than writing a `.cur`/ICO parser for one
   asset. `framebuffer.rs` grew `blend_pixel` (reads the live channel
   shifts back out of whatever's already on screen, alpha-blends the new
   colour in, writes it back) so the cursor's soft anti-aliased edges
   render properly over both the dark background and the coloured windows
   instead of a hard-edged cutout. Confirmed in QEMU: the cursor tracks
   correctly, its edges blend cleanly over every surface it was tested
   against. The pack's `.ani` files (animated cursors, a RIFF container of
   several `.cur`-like frames plus timing) are still untouched -- a
   natural follow-up once an actual "busy" state exists to show one for.
   Full regression pass afterward (`ps`/`meminfo`/`ls`) still clean, zero
   panics. Done.
9.5. ~~**Process isolation**~~ -- every ring-3 task now gets its own
   private page tables instead of all sharing the one Limine set up.
   `paging.rs` grew `new_address_space` (a fresh PML4 whose kernel-half
   entries, indices 256..511 -- HHDM, the kernel image, the heap, the
   framebuffer, all of it -- are copied from whichever address space is
   currently active, and whose low half starts completely empty),
   `map_page_in` (the same page-table-walking logic `map_page` already
   had, but targeting an arbitrary PML4 instead of always the active one,
   since a new task's mappings have to go into an address space that
   usually isn't loaded yet), and `load_cr3`. `task.rs`'s `Task` struct
   grew a `cr3` field -- every kernel thread carries the same
   `KERNEL_CR3` (captured once at boot), a ring-3 task carries its own
   private one -- and `schedule()` reloads CR3 whenever the incoming
   task's address space actually differs from the outgoing one (skipped
   otherwise, since reloading CR3 unconditionally would flush the entire
   TLB on every single kernel-thread-to-kernel-thread switch, 100 times a
   second, for no reason -- shell/counter-a/counter-b all share one
   address space and never need it). `usermode.rs` now spawns *two* demo
   tasks, each in its own address space, both mapped at the identical
   virtual address (`0x0000004000000000`) -- which would have been an
   outright collision before this (the second task's mapping would have
   silently overwritten the first's shared page-table entry, corrupting
   whichever one was still running). Confirmed in QEMU: both print their
   message independently and show up in `ps` as separately terminated
   tasks, with zero interference between them; full regression pass
   (`ps`/`meminfo`/`ls`/`gui`) still clean afterward. `write`'s pointer
   argument is still trusted rather than validated *within* a task's own
   address space (a syscall can still be handed a bad pointer inside its
   own memory and page-fault), which is a different, smaller gap than
   "no isolation at all" -- worth closing eventually, not blocking on it
   now. Done.
10. **Porting DOOM** (via [doomgeneric](https://github.com/ozkl/doomgeneric))
    -- doesn't actually require multitasking/user mode, it can run directly
    in kernel space. Tracked as its own arc, not interleaved with the
    numbered list above. First groundwork pass done:

    - ~~The red-zone gap closed~~ -- `.cargo/config.toml` now passes `-C
      no-redzone`, matching what a real `x86_64-unknown-none` target would
      give for free. Paired with `-mno-red-zone` on every C compilation
      (see below), since C compilers assume the red zone is available by
      default too.
    - ~~A much bigger heap~~ -- `heap.rs`'s `INITIAL_HEAP_SIZE` bumped from
      16 MiB to 64 MiB. `task.rs` also grew `spawn_with_stack` alongside
      the existing `spawn`, so a future DOOM task can ask for a real stack
      (a whole C game engine's call depth, not this kernel's own shallow
      Rust) instead of every kernel thread being stuck with the 32 KiB
      default.
    - ~~A C toolchain wired into the build~~ -- `build.rs` (new) shells
      out to `clang` (falling back to `cc`/`gcc`) to compile everything
      under `csrc/` with flags mirroring the Rust side's own freestanding
      setup as closely as C lets them (no red zone, the `kernel` code
      model, no stack protector, no PIC/PIE, `-ffreestanding`), archives
      the result into a static lib, and links it straight into the kernel
      binary -- no `cc` crate dependency, just `std::process::Command`,
      so `cargo build` still needs no network access in a fresh
      environment.
    - ~~A libc shim, the memory-allocation part~~ -- `libc_shim.rs`
      implements `malloc`/`free`/`calloc`/`realloc` on top of the
      existing `#[global_allocator]` (a hidden size header before each
      returned pointer is what lets `free` reconstruct the `Layout`
      Rust's allocator API needs, since libc's own `free` takes no
      size). `memcpy`/`memset`/`memmove`/`memcmp` needed no new work --
      C code calling those resolves straight against `intrinsics.rs`'s
      existing definitions, the same ones `compiler_builtins` already
      relies on.
    - Proven end to end with `csrc/cdemo.c`: real, compiled C that
      `malloc`s an array, fills and sums it, `free`s it, and calls back
      into Rust to report the result -- wired up as the `cdemo` shell
      command. Confirmed in QEMU: returns exactly the expected sum (4032),
      and a full regression pass (`ps`/`meminfo`/`ls`/`gui`) afterward is
      still clean, zero panics.
    - ~~`printf`/`sprintf`~~ -- `csrc/printf.c` (new) is a real,
      self-contained `printf` family (`printf`/`vprintf`/`fprintf`/
      `vfprintf`/`sprintf`/`snprintf`/`vsnprintf`/`puts`/`putchar`),
      hand-written against the compiler's own `__builtin_va_*` intrinsics
      rather than `<stdarg.h>` (freestanding C has no header to get them
      from, but the intrinsics themselves don't need one). Supports
      `%d`/`%i`/`%u`/`%x`/`%X`/`%o`/`%c`/`%s`/`%p`/`%%`, the `l`/`ll`
      length modifiers, zero-padding and a minimum field width, and a
      precision on `%s` -- deliberately no floating point (`%f`/`%e`/`%g`)
      yet, nothing on doomgeneric's critical path needs it so far.
      `printf`/`puts`/`putchar` reach the screen via a new `konjac_write`
      (`cfile.rs`) that both this and the file-I/O piece below share.
    - ~~File I/O~~ -- `cfile.rs` (new) implements `fopen`/`fclose`/
      `fread`/`fwrite`/`fseek`/`ftell`/`feof`/`rewind`/`fputs`/`fgets`
      plus `stdout`/`stderr`, all on top of `fat16.rs`'s existing
      whole-file `read_file`/`write_file` (there's no partial-I/O API to
      build on, so every open file is really just that whole-file `Vec`
      plus a cursor, loaded once at `fopen` and flushed once at `fclose`
      if anything changed -- more than adequate for a WAD file read in
      large chunks and essentially never written). `stdout`/`stderr` are
      the exact same handle type with a `console: true` flag rather than
      a special case bolted onto every function: writes go straight to
      `print!`, reads always report EOF (no stdin hookup -- input comes
      through `keyboard.rs`/`mouse.rs`'s own callbacks). `FILE*` itself
      stays fully opaque to C, exactly like a real libc's, matching what
      portable C code already expects. Getting this far also meant adding
      `strlen` to `intrinsics.rs` (`core::ffi::CStr::from_ptr`, used to
      read `fopen`'s C-string arguments, calls out to a real `strlen`
      symbol the same way `mem*` already did) and writing a small
      hand-rolled ASCII-only lossy-bytes-to-`String` helper instead of
      `alloc::string::String::from_utf8_lossy` -- that pulls in a
      `_Unwind_Resume` dependency this `panic = "abort"` kernel can't link
      against, the exact same gotcha as `alloc::format!` in the toolchain
      notes above.
    - Proven end to end with `csrc/iodemo.c`: real, compiled C that
      `printf`s a formatted line, `fopen`s a file for writing, `fprintf`s
      formatted text into it, closes it, reopens it for reading, `fread`s
      it back, and `printf`s the result -- wired up as the `cio` shell
      command. Confirmed in QEMU: the formatted `printf` output matches
      exactly, the file shows up afterward in `ls` at the expected size,
      and the content read back matches exactly what was written. Full
      regression pass (`cdemo`/`ps`/`meminfo`/`gui`) afterward still
      clean, zero panics.

    **DOOM itself now runs.** Booting to the title screen, navigating the
    menu, and playing a level all work in QEMU as of this pass. What
    changed:

    - ~~doomgeneric's own sources~~ -- `csrc/doom/` (new) holds 81 `.c`
      files and 97 headers, straight from [doomgeneric upstream]
      (https://github.com/ozkl/doomgeneric), chosen via the project's own
      `Makefile.linuxvt` (a maintainer-curated list of exactly the
      platform-independent engine files a minimal, framebuffer-only port
      needs) as ground truth rather than auditing ~130 files by hand.
      Everything genuinely platform-specific (X11, SDL/SDL_mixer,
      Windows, DOS, PNG screenshots) turned out to already be compiled out
      by preprocessor guards (`_WIN32`, `__MACOSX__`, `FEATURE_SOUND`,
      `HAVE_LIBPNG`, ...) that are simply never defined in this build, so
      none of it needed shimming at all -- confirmed by grepping every
      real (non-dead-code) use of anything outside the core `string.h`/
      `stdio.h`/`stdlib.h`/`ctype.h`/`math.h` surface before writing a
      single header. **This is GPL-2.0-licensed code** (id Software's
      original DOOM source plus Simon Howard's Chocolate Doom-derived
      cleanups that doomgeneric builds on -- see `csrc/doom/
      LICENSE.doomgeneric`), a meaningfully different license situation
      from the rest of this repository, worth being deliberate about
      before this project is shared or distributed anywhere.
    - ~~The rest of the header shims~~ -- `csrc/doom_include/` (new) adds
      freestanding `stdint.h`/`stdbool.h`/`stddef.h`/`stdarg.h`/
      `limits.h`/`assert.h`/`ctype.h`/`string.h`/`strings.h`/`stdlib.h`/
      `stdio.h`/`math.h`/`errno.h`/`inttypes.h`/`sys/types.h`/
      `sys/stat.h`/`unistd.h`/`fcntl.h`, compiled against with
      `-nostdinc` so nothing accidentally resolves against the build
      host's real system headers instead. The backing implementations
      landed in three places depending on what they needed: plain C
      (`csrc/doom_string.c` for `strcpy`/`strcmp`/`strchr`/`strdup`/...,
      `csrc/sscanf.c` for a deliberately narrow `sscanf` supporting only
      the `%d`/`%i`/`%x` conversions `m_config.c` actually uses) needed
      nothing from the kernel; `csrc/doom_math.c` needed the x87 FPU
      directly (`sin`/`cos`/`tan`/`atan`/`fabs`, via `fsin`/`fpatan`
      inline asm -- the *only* transcendental math anything in the
      included files calls, and only once, during `r_main.c`'s startup
      table generation, not per-frame -- safe under every task's existing
      FXSAVE/FXRSTOR area from the process-isolation work above, which
      covers x87 state as well as SSE); and `mkdir`/`getenv`/`system`/
      `exit`/`abort`/`remove`/`rename`/`qsort`/`rand`/ctype
      classification/`errno` landed in `libc_shim.rs` since they needed
      kernel-side hooks (`exit`/`abort` park the calling task forever via
      `task::yield_now()` in a loop rather than halting the machine --
      there's no task-termination primitive yet, and taking down the
      whole kernel because a DOOM assertion fired would be far worse than
      the status quo of "DOOM's task idles, everything else keeps
      running"). Every function on this list is one actually referenced
      by the 81 included files (grepped and confirmed first) -- nothing
      spent effort on symbols nothing calls.
    - ~~SSE and floating point~~ -- `build.rs` dropped the `-mno-sse
      -mno-mmx` flags the original `cdemo.c`-only groundwork used: DOOM
      needs real `float`/`double` (the transcendental math above, plus a
      mouse-acceleration check in `v_video.c`), and x86-64 SysV passes
      those in XMM registers by default, so disabling SSE would have
      silently switched to a non-standard x87-based calling convention
      instead of just failing loudly. Safe to drop given the FXSAVE point
      above.
    - ~~A legally-distributable WAD~~ -- `disk_root/DOOM1.WAD` (4,196,020
      bytes, verified `IWAD` header and the well-documented exact
      shareware file size) is id Software's 1995 shareware release,
      which its own distribution terms permit redistributing freely --
      the standard choice for a hobbyist/homebrew port. `Makefile`'s
      `DISK_SIZE_MB` went from 16 to 32 to fit it alongside everything
      else already in `disk_root/`.
    - **The platform driver** -- `csrc/doom/doomgeneric_konjac.c` (new)
      implements doomgeneric's six-function porting API. `DG_DrawFrame`
      hands doomgeneric's 640x400 `0x00RRGGBB` screen buffer to a new
      `doom_driver.rs` (`konjac_doom_blit`), which blits it onto
      `framebuffer.rs`'s `Canvas` centered on screen, repacking each
      pixel through `Canvas::put_pixel` so this works regardless of the
      real framebuffer's actual channel layout. `DG_GetTicksMs`/
      `DG_SleepMs` are built on `timer.rs`'s existing 100 Hz PIT tick
      counter (`DG_SleepMs` busy-waits with `task::yield_now()` between
      checks rather than blocking the scheduler -- there's no sleep
      queue yet). `DG_GetKey` reads from a second ring buffer in
      `keyboard.rs` (`DOOM_RING`, entirely separate from the ASCII one
      `read_char`/the shell already use) that the same IRQ1 handler now
      feeds unconditionally on every make *and* break code, translated
      through a new `SCANCODE_DOOMKEY` table mirroring doomgeneric's own
      DOS/`i_input.c` reference mapping (letters/digits pass through as
      their own unshifted ASCII, Space is `KEY_USE`, Ctrl is `KEY_FIRE`,
      arrow keys and function keys get their `doomkeys.h` codes) -- this
      is the first thing in KonjacOS that needed key-*release* events,
      not just typed characters, since DOOM needs to know when a
      movement key comes back up. `DG_SetWindowTitle` is a no-op (no
      window system to set a title on). A new `doom` shell command
      (`commands.rs`) spawns all of this as its own kernel task via
      `spawn_with_stack` (DOOM's recursive renderer and static engine
      tables want more than the default stack), clearing any stale
      queued key events left over from typing `doom` + Enter itself
      first (`keyboard::clear_doom_events`) so DOOM's first inputs aren't
      whatever was still in the queue from launching it.
    - **A real printf bug, found by DOOM itself**: the first boot attempt
      died in `HU_Init` with `W_GetNumForName: STCFN33 not found?` --
      `csrc/printf.c`'s `%.3d`-style *precision* on integer conversions
      was being parsed and then silently discarded, so `"STCFN%.3d"` was
      printing `STCFN33` instead of the zero-padded `STCFN033` the WAD's
      font lump is actually named, and the lump lookup failed. Fixed by
      having the integer-conversion path actually honor `precision` as
      "zero-pad to at least this many digits" (matching the C standard,
      and distinct from `width`, which still pads with spaces once a
      precision is given -- the leading-`0` width flag is ignored
      whenever a precision is present, same as every real `printf`).
      Exactly the kind of bug this project's whole "prove it end to end,
      don't just get it to compile" approach exists to catch.

    Confirmed in QEMU via QMP `screendump`, working from a cold boot: the
    `doom` command loads `DOOM1.WAD` from the FAT16 root (found by
    doomgeneric's own bare-filename search, `d_iwad.c`'s
    `D_FindWADByName` -- no `-iwad` argument needed, it just has to be
    sitting in the root directory of whatever's mounted, which it is),
    renders the real shareware title screen pixel-for-pixel, opens the
    main menu and the New Game skill-select menu on real keypresses, and
    starts an actual level with the in-game HUD (health/ammo/armor/face)
    and 3D view rendering. Not yet confirmed/polished: sustained gameplay
    over many frames, sound (deliberately out of scope --
    `FEATURE_SOUND` stays undefined, there's no audio driver in KonjacOS
    yet), save/load (`remove`/`rename` are stubbed to always fail --
    nothing calls them outside the save/load menu, so this fails safely
    rather than crashing), and switching back to the shell once DOOM is
    running (it's currently one-way until reboot -- there's no
    task-termination primitive to build "quit DOOM" on top of yet, noted
    above). Full regression pass (`ps`/`meminfo`/`ls`/`gui`/`cdemo`/
    `cio`) after all of this still clean, zero panics outside of DOOM's
    own task.

The [OSDev Wiki](https://wiki.osdev.org/) is the standard reference for all
of the above once you're ready for it.
